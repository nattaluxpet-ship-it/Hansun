/* ==========================================================================
   Herbal Root — script.js
   ใช้ร่วมกันทุกหน้า: แต่ละส่วนจะทำงานเฉพาะเมื่อพบ element ของหน้านั้นๆ
   - product.html : #filter-bar, #product-list, #empty-message
   - order.html   : #orderForm, #order-items, #total, #orderError,
                    #customerName, #phone, #address, #subdistrict,
                    #district, #province, #postcode, #note
   - admin.html   : #ordersTable (tbody), #pickTable (tbody), #status,
                    #reload-btn, #print-all-btn, #labelSheet
   ========================================================================== */

(function () {
  'use strict';

  /* ------------------------------------------------------------------------
     ตั้งค่า (แก้ตรงนี้)
     ------------------------------------------------------------------------ */
  var APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycby7uz_mgEKavWTxXHh7FQjmkbc1HZ7POoOdeJu2vjI4JwnspsyD5sBLwz27trA0xxGsWQ/exec';

  var CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vQf0Sqo2E10YOhHaEYmsuzY7ecTfkui0Xxio-79h5kmdxQulXHeTJqR6qD86K-nb7TDa5I3DB72HbNY/pub?gid=0&single=true&output=csv';

  // ข้อมูลผู้ส่ง ใช้พิมพ์บนใบจ่าหน้าพัสดุ
  var SHOP = {
    name: 'Herbal Root',
    phone: '0XX-XXX-XXXX',
    address: 'ใส่ที่อยู่ร้านที่นี่ (บ้านเลขที่ ถนน แขวง/ตำบล เขต/อำเภอ จังหวัด รหัสไปรษณีย์)'
  };

  // ลำดับคอลัมน์ใน Google Sheet (ต้องตรงกับ Code.gs)
  var COL = {
    time: 0, orderNo: 1, name: 2, phone: 3, address: 4, subdistrict: 5,
    district: 6, province: 7, postcode: 8, items: 9, total: 10, note: 11, status: 12
  };

  var PENDING_STATUS = 'รอแพ็ก';

  /* ------------------------------------------------------------------------
     ตัวช่วย
     ------------------------------------------------------------------------ */
  var productsPromise = null;

  function loadProducts() {
    if (!productsPromise) {
      productsPromise = fetch('products.json').then(function (res) {
        if (!res.ok) { throw new Error('HTTP ' + res.status); }
        return res.json();
      });
    }
    return productsPromise;
  }

  function formatPrice(n) {
    return Number(n).toLocaleString('th-TH');
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }

  /* ------------------------------------------------------------------------
     1) หน้า product.html
     ------------------------------------------------------------------------ */
  function initProductPage() {
    var filterBar = document.getElementById('filter-bar');
    var productList = document.getElementById('product-list');
    if (!filterBar || !productList) { return; }

    var emptyMessage = document.getElementById('empty-message');
    var filterButtons = filterBar.querySelectorAll('button');
    var validFilters = [];
    filterButtons.forEach(function (b) { validFilters.push(b.getAttribute('data-filter')); });
    var products = [];

    function showMessage(text) {
      if (emptyMessage) {
        emptyMessage.textContent = text;
        emptyMessage.hidden = false;
      } else {
        productList.textContent = text;
      }
    }

    function buildCard(product) {
      var card = el('article', 'product-card');
      card.setAttribute('data-cat', product.category);

      var imageWrap = el('div', 'product-card__image');
      var img = document.createElement('img');
      img.src = product.image;
      img.alt = product.name + ' ' + product.size;
      img.loading = 'lazy';
      img.onerror = function () { img.style.visibility = 'hidden'; };
      imageWrap.appendChild(img);

      var body = el('div', 'product-card__body');
      body.appendChild(el('h3', 'product-card__name', product.name));
      body.appendChild(el('p', 'product-card__meta', 'ขนาด ' + product.size + ' · รหัส ' + product.sku));
      body.appendChild(el('p', 'product-card__desc', product.description));

      var footer = el('div', 'product-card__footer');
      var price = el('span', 'price', formatPrice(product.price));
      price.appendChild(el('small', null, 'บาท'));

      var order = el('a', 'btn btn--accent', 'สั่งซื้อ');
      order.href = 'order.html?sku=' + encodeURIComponent(product.sku);

      footer.appendChild(price);
      footer.appendChild(order);
      body.appendChild(footer);
      card.appendChild(imageWrap);
      card.appendChild(body);
      return card;
    }

    function render(filter) {
      productList.innerHTML = '';
      if (emptyMessage) { emptyMessage.hidden = true; }

      var list = products.filter(function (p) {
        return filter === 'all' || p.category === filter;
      });

      if (list.length === 0) {
        showMessage('ยังไม่มีสินค้าในหมวดนี้');
        return;
      }
      list.forEach(function (p) { productList.appendChild(buildCard(p)); });
    }

    function setFilter(filter, updateUrl) {
      filterButtons.forEach(function (btn) {
        btn.setAttribute('aria-pressed', btn.getAttribute('data-filter') === filter ? 'true' : 'false');
      });
      render(filter);

      if (updateUrl && window.history && history.replaceState) {
        history.replaceState(null, '', filter === 'all' ? 'product.html' : 'product.html?cat=' + filter);
      }
    }

    filterButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        setFilter(btn.getAttribute('data-filter'), true);
      });
    });

    loadProducts()
      .then(function (data) {
        products = data;
        var param = (new URLSearchParams(window.location.search).get('cat') || '').toLowerCase();
        setFilter(validFilters.indexOf(param) !== -1 ? param : 'all', false);
      })
      .catch(function (error) {
        console.error(error);
        showMessage('โหลดข้อมูลสินค้าไม่สำเร็จ กรุณารีเฟรชหน้าอีกครั้ง');
      });
  }

  /* ------------------------------------------------------------------------
     2) หน้า order.html
     ------------------------------------------------------------------------ */
  function initOrderPage() {
    var form = document.getElementById('orderForm');
    var itemsBox = document.getElementById('order-items');
    var totalEl = document.getElementById('total');
    if (!form || !itemsBox || !totalEl) { return; }

    var errorEl = document.getElementById('orderError');
    var submitBtn = form.querySelector('button[type="submit"]');
    var products = [];
    var inputs = []; // { product, input }

    function showError(text) {
      if (errorEl) { errorEl.textContent = text; }
    }

    function clampQty(value) {
      var n = parseInt(value, 10);
      if (isNaN(n) || n < 0) { return 0; }
      return n > 99 ? 99 : n;
    }

    function calcTotal() {
      var total = 0;
      inputs.forEach(function (row) {
        total += row.product.price * clampQty(row.input.value);
      });
      totalEl.textContent = formatPrice(total);
      return total;
    }

    function buildRow(product, startQty) {
      var row = el('div', 'qty-row');

      var info = el('div', 'qty-row__info');
      info.appendChild(el('span', 'qty-row__name', product.name));
      info.appendChild(el('span', 'qty-row__meta',
        product.size + ' · ' + product.sku + ' · ' + formatPrice(product.price) + ' บาท'));

      var control = el('div', 'qty-control');
      var minus = el('button', null, '−');
      minus.type = 'button';
      minus.setAttribute('aria-label', 'ลดจำนวน ' + product.name + ' ' + product.size);

      var input = document.createElement('input');
      input.type = 'number';
      input.min = '0';
      input.max = '99';
      input.value = String(startQty);
      input.inputMode = 'numeric';
      input.setAttribute('aria-label', 'จำนวน ' + product.name + ' ' + product.size);

      var plus = el('button', null, '+');
      plus.type = 'button';
      plus.setAttribute('aria-label', 'เพิ่มจำนวน ' + product.name + ' ' + product.size);

      function change(delta) {
        input.value = String(clampQty(clampQty(input.value) + delta));
        showError('');
        calcTotal();
      }

      minus.addEventListener('click', function () { change(-1); });
      plus.addEventListener('click', function () { change(1); });
      input.addEventListener('input', function () { showError(''); calcTotal(); });

      control.appendChild(minus);
      control.appendChild(input);
      control.appendChild(plus);
      row.appendChild(info);
      row.appendChild(control);

      inputs.push({ product: product, input: input });
      return row;
    }

    loadProducts()
      .then(function (data) {
        products = data;
        var preselect = new URLSearchParams(window.location.search).get('sku');
        itemsBox.innerHTML = '';
        products.forEach(function (p) {
          itemsBox.appendChild(buildRow(p, p.sku === preselect ? 1 : 0));
        });
        calcTotal();
      })
      .catch(function (error) {
        console.error(error);
        itemsBox.textContent = 'โหลดรายการสินค้าไม่สำเร็จ กรุณารีเฟรชหน้าอีกครั้ง';
      });

    form.addEventListener('submit', function (event) {
      event.preventDefault();

      var lines = [];
      inputs.forEach(function (row) {
        var qty = clampQty(row.input.value);
        if (qty > 0) {
          lines.push(row.product.sku + ' ' + row.product.name + ' ' + row.product.size + ' x' + qty);
        }
      });

      if (lines.length === 0) {
        showError('กรุณาเลือกสินค้าอย่างน้อย 1 รายการ');
        return;
      }

      var payload = {
        customerName: document.getElementById('customerName').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        address: document.getElementById('address').value.trim(),
        subdistrict: document.getElementById('subdistrict').value.trim(),
        district: document.getElementById('district').value.trim(),
        province: document.getElementById('province').value.trim(),
        postcode: document.getElementById('postcode').value.trim(),
        items: lines.join('\n'),
        total: calcTotal(),
        note: document.getElementById('note').value.trim()
      };

      if (submitBtn) { submitBtn.disabled = true; }

      fetch(APPS_SCRIPT_URL, {
        method: 'POST',
        body: JSON.stringify(payload)
      })
      .then(() => { window.location.href = 'thankyou.html'; })
      .catch(error => {
        console.error(error);
        alert('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
        if (submitBtn) { submitBtn.disabled = false; }
      });
    });
  }

  /* ------------------------------------------------------------------------
     3) หน้า admin.html (รายการสั่งซื้อ + ใบหยิบสินค้า + ใบจ่าหน้าพัสดุ)
     ------------------------------------------------------------------------ */

  // parse CSV แบบเขียนเอง (RFC 4180): รองรับ "..." ที่มี comma/ขึ้นบรรทัดใหม่ และ "" แทน "
  function parseCSV(text) {
    var rows = [];
    var row = [];
    var field = '';
    var inQuotes = false;
    var i = 0;

    if (text.charCodeAt(0) === 0xFEFF) { text = text.slice(1); }

    while (i < text.length) {
      var ch = text[i];

      if (inQuotes) {
        if (ch === '"') {
          if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
          inQuotes = false;
          i++;
          continue;
        }
        field += ch;
        i++;
        continue;
      }

      if (ch === '"') {
        inQuotes = true;
        i++;
      } else if (ch === ',') {
        row.push(field);
        field = '';
        i++;
      } else if (ch === '\r' || ch === '\n') {
        row.push(field);
        rows.push(row);
        row = [];
        field = '';
        if (ch === '\r' && text[i + 1] === '\n') { i++; }
        i++;
      } else {
        field += ch;
        i++;
      }
    }

    if (field !== '' || row.length > 0) {
      row.push(field);
      rows.push(row);
    }
    return rows;
  }

  // แปลงข้อความรายการสินค้า (บรรทัดละ 1 รายการ "SKU ชื่อ ขนาด xจำนวน") เป็น array
  function parseItems(text) {
    var result = [];
    (text || '').split(/\r?\n/).forEach(function (line) {
      line = line.trim();
      if (!line) { return; }
      var m = line.match(/^(\S+)\s+(.+?)\s+x(\d+)$/);
      if (m) {
        result.push({ sku: m[1], name: m[2], qty: parseInt(m[3], 10) });
      } else {
        result.push({ sku: '?', name: line, qty: 0 });
      }
    });
    return result;
  }

  function cell(row, key) {
    var v = row[COL[key]];
    return v === undefined ? '' : v;
  }

  function isPending(row) {
    var s = cell(row, 'status').trim();
    return s === '' || s === PENDING_STATUS;
  }

  function oneLineAddress(row) {
    return [cell(row, 'address'), cell(row, 'subdistrict'), cell(row, 'district'),
            cell(row, 'province'), cell(row, 'postcode')]
      .filter(function (s) { return s.trim() !== ''; })
      .join(' ');
  }

  function initAdminPage() {
    var tbody = document.querySelector('#ordersTable tbody');
    if (!tbody) { return; }

    var pickBody = document.querySelector('#pickTable tbody');
    var statusEl = document.getElementById('status');
    var reloadBtn = document.getElementById('reload-btn');
    var printAllBtn = document.getElementById('print-all-btn');
    var labelSheet = document.getElementById('labelSheet');
    var orders = [];

    function setStatus(text) {
      if (statusEl) { statusEl.textContent = text; }
    }

    function messageRow(target, cols, text) {
      target.innerHTML = '';
      var tr = document.createElement('tr');
      var td = el('td', 'text-center text-muted', text);
      td.colSpan = cols;
      tr.appendChild(td);
      target.appendChild(tr);
    }

    /* ---- ใบจ่าหน้าพัสดุ ---- */
    function buildLabel(row) {
      var label = el('div', 'label');

      var from = el('div', 'label__from');
      from.appendChild(el('div', 'label__tag', 'ผู้ส่ง'));
      from.appendChild(el('div', 'label__strong', SHOP.name + '  โทร ' + SHOP.phone));
      from.appendChild(el('div', 'label__pre', SHOP.address));

      var to = el('div', 'label__to');
      to.appendChild(el('div', 'label__tag', 'ผู้รับ'));
      to.appendChild(el('div', 'label__name', cell(row, 'name')));
      to.appendChild(el('div', 'label__strong', 'โทร ' + cell(row, 'phone')));
      to.appendChild(el('div', 'label__pre',
        cell(row, 'address') + '\n' +
        (cell(row, 'subdistrict') + ' ' + cell(row, 'district')).trim() + '\n' +
        (cell(row, 'province') + ' ' + cell(row, 'postcode')).trim()));

      var items = el('div', 'label__items');
      items.appendChild(el('div', 'label__tag', 'รายการสินค้า'));
      parseItems(cell(row, 'items')).forEach(function (it) {
        items.appendChild(el('div', null, it.sku + '  ' + it.name + '  x' + it.qty));
      });

      var foot = el('div', 'label__foot');
      foot.appendChild(el('span', null, 'เลขออเดอร์ ' + cell(row, 'orderNo')));
      if (cell(row, 'note').trim()) {
        foot.appendChild(el('span', 'label__pre', 'หมายเหตุ: ' + cell(row, 'note')));
      }

      label.appendChild(from);
      label.appendChild(to);
      label.appendChild(items);
      label.appendChild(foot);
      return label;
    }

    function printLabels(rows) {
      if (!labelSheet) { return; }
      if (rows.length === 0) {
        alert('ไม่มีออเดอร์ที่ต้องพิมพ์');
        return;
      }
      labelSheet.innerHTML = '';
      rows.forEach(function (r) { labelSheet.appendChild(buildLabel(r)); });

      document.body.classList.add('printing-labels');
      window.addEventListener('afterprint', function () {
        document.body.classList.remove('printing-labels');
      }, { once: true });
      window.print();
    }

    /* ---- ตารางออเดอร์ ---- */
    function renderOrders() {
      tbody.innerHTML = '';
      orders.forEach(function (row) {
        var tr = document.createElement('tr');

        tr.appendChild(el('td', 'time', cell(row, 'orderNo')));
        tr.appendChild(el('td', 'time', cell(row, 'time')));

        var who = document.createElement('td');
        who.appendChild(el('div', null, cell(row, 'name')));
        who.appendChild(el('div', 'text-muted', cell(row, 'phone')));
        tr.appendChild(who);

        tr.appendChild(el('td', null, oneLineAddress(row)));

        var itemsTd = el('td', 'pre');
        itemsTd.textContent = cell(row, 'items');
        tr.appendChild(itemsTd);

        tr.appendChild(el('td', 'num', cell(row, 'total')));
        tr.appendChild(el('td', null, cell(row, 'status') || PENDING_STATUS));

        var actionTd = document.createElement('td');
        var btn = el('button', 'btn btn--small', 'ใบจ่าหน้า');
        btn.type = 'button';
        btn.addEventListener('click', function () { printLabels([row]); });
        actionTd.appendChild(btn);
        tr.appendChild(actionTd);

        tbody.appendChild(tr);
      });
    }

    /* ---- ใบหยิบสินค้า (รวมจำนวนตาม SKU เฉพาะออเดอร์ที่รอแพ็ก) ---- */
    function renderPickList() {
      if (!pickBody) { return; }
      var map = {};
      var order = [];

      orders.filter(isPending).forEach(function (row) {
        parseItems(cell(row, 'items')).forEach(function (it) {
          if (!map[it.sku]) {
            map[it.sku] = { sku: it.sku, name: it.name, qty: 0 };
            order.push(it.sku);
          }
          map[it.sku].qty += it.qty;
        });
      });

      if (order.length === 0) {
        messageRow(pickBody, 3, 'ไม่มีสินค้าที่ต้องหยิบ');
        return;
      }

      pickBody.innerHTML = '';
      order.sort().forEach(function (sku) {
        var item = map[sku];
        var tr = document.createElement('tr');
        tr.appendChild(el('td', 'time', item.sku));
        tr.appendChild(el('td', null, item.name));
        tr.appendChild(el('td', 'num', String(item.qty)));
        pickBody.appendChild(tr);
      });
    }

    function loadOrders() {
      setStatus('กำลังโหลดข้อมูล...');
      if (reloadBtn) { reloadBtn.disabled = true; }

      fetch(CSV_URL)
        .then(function (res) {
          if (!res.ok) { throw new Error('HTTP ' + res.status); }
          return res.text();
        })
        .then(function (text) {
          var rows = parseCSV(text).filter(function (row) {
            return !row.every(function (cell) { return cell.trim() === ''; });
          });

          // ข้ามแถวหัวคอลัมน์ ถ้าคอลัมน์ A ไม่มีตัวเลขเลย (ไม่ใช่วันที่)
          if (rows.length > 0 && !/\d/.test(rows[0][0])) { rows.shift(); }

          // appendRow ต่อท้ายตามเวลา จึงกลับลำดับให้ล่าสุดขึ้นก่อน
          rows.reverse();
          orders = rows;

          if (orders.length === 0) {
            messageRow(tbody, 8, 'ยังไม่มีรายการสั่งซื้อ');
            messageRow(pickBody || tbody, 3, 'ไม่มีสินค้าที่ต้องหยิบ');
            setStatus('ทั้งหมด 0 ออเดอร์');
            return;
          }

          renderOrders();
          renderPickList();
          var pending = orders.filter(isPending).length;
          setStatus('ทั้งหมด ' + orders.length + ' ออเดอร์ · รอแพ็ก ' + pending + ' ออเดอร์');
        })
        .catch(function (error) {
          console.error(error);
          messageRow(tbody, 8, 'โหลดข้อมูลไม่สำเร็จ กรุณาลองใหม่อีกครั้ง');
          setStatus('เกิดข้อผิดพลาดในการโหลดข้อมูล');
        })
        .then(function () {
          if (reloadBtn) { reloadBtn.disabled = false; }
        });
    }

    if (reloadBtn) { reloadBtn.addEventListener('click', loadOrders); }
    if (printAllBtn) {
      printAllBtn.addEventListener('click', function () {
        printLabels(orders.filter(isPending));
      });
    }
    loadOrders();
  }

  /* ------------------------------------------------------------------------
     เริ่มทำงาน
     ------------------------------------------------------------------------ */
  function init() {
    initProductPage();
    initOrderPage();
    initAdminPage();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
